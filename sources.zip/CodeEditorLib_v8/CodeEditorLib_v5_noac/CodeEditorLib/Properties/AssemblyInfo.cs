using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CodeEditorLib")]
[assembly: AssemblyDescription("Code Editor Control Library for .NET")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ari Sohandri Putra")]
[assembly: AssemblyProduct("CodeEditorLib")]
[assembly: AssemblyCopyright("© 2026 Ari Sohandri Putra. All Rights Reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("a1b2c3d4-e5f6-7890-abcd-ef1234567890")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
