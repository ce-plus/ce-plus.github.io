; =========================================================
;  CE++ Code Editor — Inno Setup Installer Script
;  Author    : Ari Sohandri Putra
;  Website   : https://ce-plus.github.io
;  Version   : 1.0
;
;  Struktur folder yang diperlukan di sebelah script ini:
;
;  Win7\
;    x86\  CE++.exe  CodeEditorLib.dll  license.txt  Language\*
;    x64\  CE++.exe  CodeEditorLib.dll  license.txt  Language\*
;  WinNew\
;    x86\  CE++.exe  CodeEditorLib.dll  license.txt  Language\*
;    x64\  CE++.exe  CodeEditorLib.dll  license.txt  Language\*
;  icon.ico
;  license.txt
;  CE++_Setup.iss   ← file ini
; =========================================================

#define MyAppName        "CE++ Code Editor"
#define MyAppVersion     "1.0"
#define MyAppPublisher   "Ari Sohandri Putra"
#define MyAppURL         "https://ce-plus.github.io"
#define MyAppExeName     "CE++.exe"
#define MyAppId          "{{8F6B8D4C-8C4A-4F1E-9B72-CEPLUSPLUS001}"

; ----------------------------------------------------------
; [Setup]
; ----------------------------------------------------------
[Setup]

; --- Identity ---
AppId={#MyAppId}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
AppCopyright=Copyright (C) 2026 {#MyAppPublisher}

; --- Output ---
OutputDir=Output
OutputBaseFilename=CE++_Setup_v{#MyAppVersion}
SetupIconFile=icon.ico
Compression=lzma2
SolidCompression=yes

; --- Install path ---
; 64-bit OS → C:\Program Files\CE++ Code Editor
; 32-bit OS → C:\Program Files\CE++ Code Editor
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
AllowNoIcons=yes

; --- Privileges ---
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog

; --- Architecture ---
; Jangan set ArchitecturesInstallIn64BitMode di sini.
; Kita kontrol sendiri lewat fungsi Check di [Files].
; Installer ini berjalan sebagai proses 32-bit di semua OS,
; tapi fungsi IsX64OS() mendeteksi apakah Windows-nya 64-bit.

; --- Minimum OS: Windows Vista (NT 6.0) ---
MinVersion=6.1

; --- Wizard ---
WizardStyle=modern
WizardResizable=no
UsePreviousAppDir=yes

; --- License ---
LicenseFile=license.txt

; --- Uninstall ---
UninstallDisplayIcon={app}\{#MyAppExeName}
UninstallDisplayName={#MyAppName}

; --- EXE Version Manifest ---
VersionInfoVersion=1.0.0.0
VersionInfoCompany={#MyAppPublisher}
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
VersionInfoDescription=The fast, free, open source code editor for Windows.
VersionInfoCopyright=Copyright (C) 2026 {#MyAppPublisher}
VersionInfoOriginalFileName=CE++_Setup_v{#MyAppVersion}.exe

; ----------------------------------------------------------
; [Languages]
; ----------------------------------------------------------
[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

; ----------------------------------------------------------
; [Tasks]
; ----------------------------------------------------------
[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut";                          GroupDescription: "Additional shortcuts:"
Name: "quicklaunch"; Description: "Create a &Quick Launch shortcut";                     GroupDescription: "Additional shortcuts:"; Flags: unchecked
Name: "fileassoc";   Description: "Associate CE++ with all supported source file types"; GroupDescription: "File associations:";    Flags: unchecked

; ----------------------------------------------------------
; [Files]
;
; Empat grup file berdasarkan kombinasi OS + arsitektur:
;   IsVistaSeven_x86  → Vista/7  + Windows 32-bit
;   IsVistaSeven_x64  → Vista/7  + Windows 64-bit
;   IsWin8Plus_x86    → Win8/10/11 + Windows 32-bit
;   IsWin8Plus_x64    → Win8/10/11 + Windows 64-bit
;
; Flag "solidbreak" memulai blok kompresi baru per grup
; sehingga installer hanya mendekompresi grup yang dipakai.
; ----------------------------------------------------------
[Files]

; ==========================================================
; Windows Vista / 7  —  32-bit (x86)
; ==========================================================
Source: "Win7\x86\{#MyAppExeName}";   DestDir: "{app}";          Flags: ignoreversion solidbreak;                     Check: IsVistaSeven_x86
Source: "Win7\x86\CodeEditorLib.dll"; DestDir: "{app}";          Flags: ignoreversion;                                Check: IsVistaSeven_x86
Source: "Win7\x86\license.txt";       DestDir: "{app}";          Flags: ignoreversion;                                Check: IsVistaSeven_x86
Source: "Win7\x86\Languages\*";        DestDir: "{app}\Languages"; Flags: ignoreversion recursesubdirs createallsubdirs; Check: IsVistaSeven_x86

; ==========================================================
; Windows Vista / 7  —  64-bit (x64)
; ==========================================================
Source: "Win7\x64\{#MyAppExeName}";   DestDir: "{app}";          Flags: ignoreversion solidbreak;                     Check: IsVistaSeven_x64
Source: "Win7\x64\CodeEditorLib.dll"; DestDir: "{app}";          Flags: ignoreversion;                                Check: IsVistaSeven_x64
Source: "Win7\x64\license.txt";       DestDir: "{app}";          Flags: ignoreversion;                                Check: IsVistaSeven_x64
Source: "Win7\x64\Languages\*";        DestDir: "{app}\Languages"; Flags: ignoreversion recursesubdirs createallsubdirs; Check: IsVistaSeven_x64

; ==========================================================
; Windows 8 / 10 / 11  —  32-bit (x86)
; ==========================================================
Source: "WinNew\x86\{#MyAppExeName}";   DestDir: "{app}";          Flags: ignoreversion solidbreak;                     Check: IsWin8Plus_x86
Source: "WinNew\x86\CodeEditorLib.dll"; DestDir: "{app}";          Flags: ignoreversion;                                Check: IsWin8Plus_x86
Source: "WinNew\x86\license.txt";       DestDir: "{app}";          Flags: ignoreversion;                                Check: IsWin8Plus_x86
Source: "WinNew\x86\Languages\*";        DestDir: "{app}\Languages"; Flags: ignoreversion recursesubdirs createallsubdirs; Check: IsWin8Plus_x86

; ==========================================================
; Windows 8 / 10 / 11  —  64-bit (x64)
; ==========================================================
Source: "WinNew\x64\{#MyAppExeName}";   DestDir: "{app}";          Flags: ignoreversion solidbreak;                     Check: IsWin8Plus_x64
Source: "WinNew\x64\CodeEditorLib.dll"; DestDir: "{app}";          Flags: ignoreversion;                                Check: IsWin8Plus_x64
Source: "WinNew\x64\license.txt";       DestDir: "{app}";          Flags: ignoreversion;                                Check: IsWin8Plus_x64
Source: "WinNew\x64\Languages\*";        DestDir: "{app}\Languages"; Flags: ignoreversion recursesubdirs createallsubdirs; Check: IsWin8Plus_x64

; ----------------------------------------------------------
; [Registry]  — File Associations (optional, task-gated)
; ----------------------------------------------------------
[Registry]

; ProgID tunggal untuk semua ekstensi
Root: HKA; Subkey: "Software\Classes\CE++File";                    ValueType: string; ValueName: ""; ValueData: "Source Code File";                Flags: uninsdeletekey;   Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\CE++File\DefaultIcon";        ValueType: string; ValueName: ""; ValueData: "{app}\{#MyAppExeName},0";         Flags: uninsdeletekey;   Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\CE++File\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#MyAppExeName}"" ""%1"""; Flags: uninsdeletekey;   Tasks: fileassoc

; Plain Text
Root: HKA; Subkey: "Software\Classes\.txt\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; C / C++
Root: HKA; Subkey: "Software\Classes\.c\OpenWithProgids";    ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.cpp\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.cc\OpenWithProgids";   ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.cxx\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.h\OpenWithProgids";    ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.hpp\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; C#
Root: HKA; Subkey: "Software\Classes\.cs\OpenWithProgids";   ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; CSS
Root: HKA; Subkey: "Software\Classes\.css\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; Go
Root: HKA; Subkey: "Software\Classes\.go\OpenWithProgids";   ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; HTML
Root: HKA; Subkey: "Software\Classes\.html\OpenWithProgids"; ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.htm\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; Java
Root: HKA; Subkey: "Software\Classes\.java\OpenWithProgids"; ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; JavaScript / TypeScript
Root: HKA; Subkey: "Software\Classes\.js\OpenWithProgids";   ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.mjs\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.ts\OpenWithProgids";   ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.tsx\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.jsx\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; PHP
Root: HKA; Subkey: "Software\Classes\.php\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.phtml\OpenWithProgids";ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; Python
Root: HKA; Subkey: "Software\Classes\.py\OpenWithProgids";   ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.pyw\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; Rust
Root: HKA; Subkey: "Software\Classes\.rs\OpenWithProgids";   ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; SQL
Root: HKA; Subkey: "Software\Classes\.sql\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; VB.NET
Root: HKA; Subkey: "Software\Classes\.vb\OpenWithProgids";   ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.vbs\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; XML
Root: HKA; Subkey: "Software\Classes\.xml\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.xsl\OpenWithProgids";  ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc
Root: HKA; Subkey: "Software\Classes\.xslt\OpenWithProgids"; ValueType: string; ValueName: "CE++File"; ValueData: ""; Flags: uninsdeletevalue; Tasks: fileassoc

; ----------------------------------------------------------
; [Icons]
; ----------------------------------------------------------
[Icons]
Name: "{group}\{#MyAppName}";           Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}";     Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
Name: "{userappdata}\Microsoft\Internet Explorer\Quick Launch\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: quicklaunch

; ----------------------------------------------------------
; [Run]  — launch setelah install selesai
; ----------------------------------------------------------
[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent

; ----------------------------------------------------------
; [UninstallRun]  — matikan proses sebelum uninstall
; ----------------------------------------------------------
[UninstallRun]
Filename: "{sys}\taskkill.exe"; Parameters: "/f /im {#MyAppExeName}"; Flags: nowait skipifdoesntexist runhidden

; ----------------------------------------------------------
; [Messages]
; ----------------------------------------------------------
[Messages]
WelcomeLabel1=Welcome to the [name] Setup Wizard
WelcomeLabel2=This will install [name/ver] on your computer.%n%nPlease close all other applications before continuing.
FinishedLabel=Setup has finished installing [name] on your computer.%n%nYou can launch the application from the Start Menu or desktop shortcut.

; ----------------------------------------------------------
; [Code]  — Pascal scripting
; ----------------------------------------------------------
[Code]

{ ============================================================
  Deteksi versi OS
  ============================================================ }

{ TRUE = Windows Vista atau Windows 7 (NT 6.0 – 6.1.x) }
function IsVistaSeven(): Boolean;
begin
  Result := (GetWindowsVersion >= $06000000) and
            (GetWindowsVersion <  $06020000);
end;

{ TRUE = Windows 8, 10, atau 11 (NT 6.2+) }
function IsWin8Plus(): Boolean;
begin
  Result := GetWindowsVersion >= $06020000;
end;

{ ============================================================
  Deteksi arsitektur CPU / Windows
  IsX64OS() adalah fungsi bawaan Inno Setup:
    TRUE  → Windows yang terinstall adalah 64-bit
    FALSE → Windows yang terinstall adalah 32-bit
  ============================================================ }

function IsX86OS(): Boolean;
begin
  Result := not IsX64OS();
end;

{ ============================================================
  Empat fungsi Check gabungan untuk [Files]
  ============================================================ }

function IsVistaSeven_x86(): Boolean;
begin
  Result := IsVistaSeven() and IsX86OS();
end;

function IsVistaSeven_x64(): Boolean;
begin
  Result := IsVistaSeven() and IsX64OS();
end;

function IsWin8Plus_x86(): Boolean;
begin
  Result := IsWin8Plus() and IsX86OS();
end;

function IsWin8Plus_x64(): Boolean;
begin
  Result := IsWin8Plus() and IsX64OS();
end;

{ ============================================================
  InitializeSetup
  Blokir OS yang tidak didukung (di bawah Vista).
  ============================================================ }
function InitializeSetup(): Boolean;
begin
  Result := True;

  if GetWindowsVersion < $06000000 then
  begin
    MsgBox(
      '{#MyAppName} requires Windows Vista or later.' + #13#10 +
      'Your current version of Windows is not supported.' + #13#10 + #13#10 +
      'Please upgrade your operating system and try again.',
      mbCriticalError, MB_OK
    );
    Result := False;
  end;
end;

{ ============================================================
  InitializeWizard
  Fine-tune tampilan wizard.
  ============================================================ }
procedure InitializeWizard();
begin
  WizardForm.WelcomeLabel2.Font.Size := 9;
end;

{ ============================================================
  CurStepChanged
  Sebelum install: matikan proses CE++ yang sedang berjalan
  agar file tidak terkunci saat disalin.
  ============================================================ }
procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
begin
  if CurStep = ssInstall then
    Exec(
      ExpandConstant('{sys}\taskkill.exe'),
      '/f /im {#MyAppExeName}',
      '', SW_HIDE, ewWaitUntilTerminated, ResultCode
    );
end;

{ ============================================================
  CurUninstallStepChanged
  Tawarkan penghapusan data pengguna setelah uninstall.
  ============================================================ }
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
  begin
    if MsgBox(
      'Do you also want to remove all {#MyAppName} user settings and preferences?',
      mbConfirmation, MB_YESNO
    ) = IDYES then
      DelTree(ExpandConstant('{userappdata}\{#MyAppName}'), True, True, True);
  end;
end;
